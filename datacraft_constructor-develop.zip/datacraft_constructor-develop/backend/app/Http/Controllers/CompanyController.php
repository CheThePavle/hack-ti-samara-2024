<?php

namespace App\Http\Controllers;

use App\Models\Company;
use Illuminate\Http\Request;

class CompanyController extends Controller
{
    public function list() {
        return success(Company::all());
    }

    public function confirmed() {

    }
}
