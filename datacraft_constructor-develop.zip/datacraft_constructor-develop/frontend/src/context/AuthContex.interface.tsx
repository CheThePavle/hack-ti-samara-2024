export interface AuthContextProps {
    isAuthenticated: boolean;
    user: any | null;
    currentUser: any | null;
    login: (email: string, password: string, companyId: string) => Promise<void>;
    register: (name: string, email: string, password: string, companyId: string) => Promise<void>;
    logout: () => void;
}
