// export interface MockUser {
//     id: string;
//     email: string;
//     password: string;
//     companyId: string;
//     name: string;
//     role: string;
// }
//
// // Пример пользователей
// export const mockUsers: MockUser[] = [
//     {
//         id: '1',
//         email: 'user1@example.com',
//         password: '123',
//         companyId: '123',
//         name: 'Иван Иванов',
//         role: 'admin'
//     },
//     {
//         id: '2',
//         email: 'user2@example.com',
//         password: '123',
//         companyId: '123',
//         name: 'Сергей Сергеев',
//         role: 'user'
//     },
// ];