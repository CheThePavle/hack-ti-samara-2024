import { FC, useState, useEffect } from 'react';
import styles from './AccessControl.module.sass';
import { User } from "./AccessControl.interface.ts";
import REACT_APP_API_URL from "../../../env.ts";

import agree from "../../assets/agree.svg";
import close from "../../assets/close.svg";

const AccessControl: FC = () => {
    const [users, setUsers] = useState<User[]>([]);
    const [isAdmin, setIsAdmin] = useState(false);

    useEffect(() => {
        const role = localStorage.getItem('role');
        setIsAdmin(role === '2');
    }, []);

    useEffect(() => {
        if (isAdmin) {
            const fetchUsers = async () => {
                try {
                    const response = await fetch(`${REACT_APP_API_URL}/api/users`, {
                        method: 'GET',
                        headers: {
                            'Authorization': 'Bearer ' + localStorage.getItem('api_token'),
                            'Content-Type': 'application/json',
                        },
                    });
                    const data = await response.json();

                    if (data.success) {
                        setUsers(data.data); // Загружаем всех пользователей
                    }
                } catch (error) {
                    console.error("Ошибка при загрузке пользователей:", error);
                }
            };

            fetchUsers();
        }
    }, [isAdmin]);

    const handleAccessChange = async (userId: number, allowAccess: boolean) => {
        try {
            // Подтверждение пользователя
            if (allowAccess) {
                const response = await fetch(`${REACT_APP_API_URL}/api/user/confirmed`, {
                    method: 'PATCH',
                    headers: {
                        'Authorization': 'Bearer ' + localStorage.getItem('api_token'),
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ user_id: userId }),
                });

                const data = await response.json();

                if (data.success) {
                    setUsers((prevUsers) =>
                        prevUsers.map((user) =>
                            user.id === userId ? { ...user, confirmed: true, accessAllowed: true } : user
                        )
                    );
                } else {
                    console.error("Ошибка при обновлении статуса пользователя:", data);
                }
            } else {
                // Удаление пользователя
                const response = await fetch(`${REACT_APP_API_URL}/api/user`, {
                    method: 'DELETE',
                    headers: {
                        'Authorization': 'Bearer ' + localStorage.getItem('api_token'),
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ user_id: userId }),
                });

                const data = await response.json();

                if (data.success) {
                    setUsers((prevUsers) => prevUsers.filter((user) => user.id !== userId));
                } else {
                    console.error("Ошибка при удалении пользователя:", data);
                }
            }
        } catch (error) {
            console.error("Ошибка при отправке запроса:", error);
        }
    };

    if (!isAdmin) {
        return <p>У вас нет доступа к этой странице.</p>;
    }

    return (
        <div className={styles.accessControl}>
            <ul className={styles.userList}>
                {users.map((user) => (
                    <li key={user.id} className={styles.userItem}>
                        <div className={styles.userInfo}>
                            <p>{user.name}</p>
                            <p>{user.email}</p>
                        </div>
                        <div className={styles.actionButtons}>
                            {user.confirmed === null && (
                                <button
                                    className={`${styles.allowButton}`}
                                    onClick={() => handleAccessChange(user.id, true)}
                                >
                                    <p>Разрешить</p>
                                    <img src={agree} alt="agree"/>
                                </button>
                            )}
                            <button
                                className={`${styles.denyButton}`}
                                onClick={() => handleAccessChange(user.id, false)}
                            >
                                <p>Удалить</p>
                                <img src={close} alt="deny"/>
                            </button>
                        </div>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default AccessControl;
