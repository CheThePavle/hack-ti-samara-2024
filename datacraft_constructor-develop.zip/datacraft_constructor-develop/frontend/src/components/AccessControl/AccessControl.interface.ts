export interface User {
    id: number;
    role_id: number;
    company_id: number;
    confirmed: boolean | null;
    name: string;
    email: string;
    created_at: string;
    updated_at: string;
    role: {
        id: number;
        name: string;
        created_at: string;
        updated_at: string;
    };
    company: {
        id: number;
        name: string;
        created_at: string;
        updated_at: string;
    };
    accessAllowed: boolean;
}
