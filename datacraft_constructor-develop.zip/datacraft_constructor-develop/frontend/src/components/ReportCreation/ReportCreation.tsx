import {useState, useEffect, FC} from "react";
import styles from "./ReportCreation.module.sass";

import play from '../../assets/play.svg';
import screp from '../../assets/screp.svg';

import REACT_APP_API_URL from '../../../env';


interface CustomColumn {
    id?: number;
    name: string;
    type: "a" | "fx";
    title?: string;
    fx?: string;
    where?: { [key: string]: any };
}

interface Category {
    id: number;
    name: string;
}

interface ReportData {
    name: string;
    headers: CustomColumn[];
    data: any[];
    extension: string;
    category_id: string;
}

interface ReportCreationProps {
    idReport: number;
}

// interface CustomColumn {
//     id: number;
//     name: string;
//     type: "a" | "f(x)";
//     condition: string;
// }

// const uniqueArrayObjects = array.reduce((accumulator, current) => {
//     if (accumulator.findIndex(object => object.name === current.name) === -1) {
//       accumulator.push(current);
//     }
//     return accumulator;
//   }, []);

const ReportCreation: FC<ReportCreationProps> = ({ idReport }) => {
    // fixme передавать сюда потом id выбранного отчета из списка
    console.log(idReport);
    const [customWhereColumns, setCustomWhereColumns] = useState<CustomColumn[]>([]); // Список кастомных столбцов по условию
    // const [customColumns, setCustomColumns] = useState<CustomColumn[]>([]); // Список кастомных столбцов
    const [dataWhereColumns, setDataWhereColumns] = useState<string[]>([]); // Список доступных условий для столбцов
    const [dataHeaders, setDataHeaders] = useState<CustomColumn[]>([]); // инфа по заголовкам
    const [dataReport, setDataReport] = useState<any[]>([]); // инфа по строкам в отчете
    const [newDataReport, setNewDataReport] = useState<any[]>([]); // по условиям инфа по строкам в отчете
    const [dataCategories, setDataCategories] = useState<Category[]>([]); // инфа по категориям
    const [dataExtensions, setDataExtensions] = useState<string[]>([]); // инфа по расширениям
    const [name, setName] = useState<string>(""); // Имя отчета
    const [selectedExtension, setSelectedExtension] = useState<string>(""); // Расширение
    const [selectedCategory, setSelectedCategory] = useState<string>(""); // Выбранная категория

    const handleAddWhereColumn = () => {
        for (let i = 0; i < customWhereColumns.length; i++) {
            if (Array.isArray(customWhereColumns[i].where)) {
                customWhereColumns[i].where = {};
                break;
            };
        }

        setCustomWhereColumns([...customWhereColumns]);
        // if (customColumns.length !== customWhereColumns.length) {
        //     const whereColumn = customColumns[customWhereColumns.length];
        //     whereColumn.where = {};
        //     customWhereColumns.push(customColumns[customWhereColumns.length]);
    
        //     setCustomWhereColumns([...customWhereColumns]);
        // }
    };

    // TODO условия работают только одно на один столбец
    const handleColumnWhereChange = (name, field, value = '', where = false) => {
        setCustomWhereColumns([...customWhereColumns.map(column => {
            if (column.name === name) {
                column.where = Array.isArray(column.where) ? {} : column.where;

                if (where) column.where[field] = value;             
            } else {  //  if (Object.keys(column.where).length === 0)
                column.where = [];
            }
            return column;
        })]);

        console.log('Условия выборки полей изменились');
        console.log(customWhereColumns);
    };

    const handleDeleteWhereColumn = (name) => {
        for (let i = 0; i < customWhereColumns.length; i++) {
            if (customWhereColumns[i].name === name) {
                customWhereColumns[i].where = [];
                break;
            };
        }
        console.log('Удаление условия для столбца');
        console.log(customWhereColumns);
        
        setCustomWhereColumns([...customWhereColumns]);
    };

    const handleAddColumn = () => {
        setCustomWhereColumns([...customWhereColumns, { fx: "", type: "a", name: "new_column_" + customWhereColumns.length, title: "", where: [] }]);

        console.log('Условия настройки полей изменились');
        console.log(customWhereColumns);
    };

    const handleColumnChange = (index, field, value = '') => {
        setCustomWhereColumns([...customWhereColumns.map((column, iCol) => {
            if (iCol === index) {
                column[field] = value;
            }
            return column;
        })]);

        console.log('Условия настройки полей изменились');
        console.log(customWhereColumns);
    };

    const handleDeleteColumn = (index) => {
        const newRecords = [];
        const newColumns = customWhereColumns.filter((column, iCol) => {
            if (iCol === index) {
                console.log({column, iCol, index});

                dataReport.map((records) => {

                    records.splice(index, 1);
                    // console.log({
                    //     iRec,
                    //     iCol,
                    //     record
                    // });
                    newRecords.push(records);
                    // dataReport.map((record, iRec) => {
                    //     if (iCol - iRec === 1) {
                  
                    //     };
                        
                    // });
                });

            };

            return iCol !== index;
        });

        console.log('===============new===========');
        console.log({newRecords});
        
        setNewDataReport([...newRecords]);
        setCustomWhereColumns([...newColumns]);
    };

    useEffect(() => {
        const bearerToken = localStorage.getItem('api_token');

        fetch(`${REACT_APP_API_URL}/api/report/${idReport}`, {
            method: 'GET',
            headers: {
              'Authorization': 'Bearer ' + bearerToken,
            },
          })
            .then((response) => response.json())
            .then((data) => {
              if (data.success) {
                const report = data.data;
                console.log('Получили данные об отчете');
                console.log(data);

                setName(report.name);
                setDataHeaders(report.headers);
                setCustomWhereColumns(report.headers);
                // setCustomColumns(report.headers);
                setDataReport(report?.whereData?.length > 0 ? report.whereData : report.data);
                setSelectedExtension(report.extension);
                setSelectedCategory(report.category_id);
              } else alert(JSON.stringify(data));
            }
          )

          fetch(`${REACT_APP_API_URL}/api/categories`, {
            method: 'GET',
            headers: {
              'Authorization': 'Bearer ' + bearerToken,
            },
          })
            .then((response) => response.json())
            .then((data) => {
              if (data.success) {
                setDataCategories(data.data);
                console.log('Получили данные об категориях');
                console.log(data);
              } else alert(JSON.stringify(data));
            }
          )

          fetch(`${REACT_APP_API_URL}/api/where`, {
            method: 'GET',
            headers: {
              'Authorization': 'Bearer ' + bearerToken,
            },
          })
            .then((response) => response.json())
            .then((data) => {
              if (data.success) {
                setDataWhereColumns(data.data);
                console.log('Получили данные об доступных условий для столбцов');
                console.log(data);
              } else alert(JSON.stringify(data));
            }
          )

          fetch(`${REACT_APP_API_URL}/api/report/extensions`, {
            method: 'GET',
            headers: {
              'Authorization': 'Bearer ' + bearerToken,
            },
          })
            .then((response) => response.json())
            .then((data) => {
              if (data.success) {
                setDataExtensions(data.data);
                console.log('Получили данные об расширении файлов');
                console.log(data);
              } else alert(JSON.stringify(data));
            }
          )
    }, []);

    const filterDataReport = () => {
        const arrayData = dataReport;
        const newArrayWhereData = [];

        customWhereColumns.map((column, iCol) => {
            if (column.fx) {
                console.log('=======fx==========');
                console.log(column);

                arrayData.map((records) => {
                    records.map((record, iRec) => {
                        if (iRec === customWhereColumns.findIndex(el => el.name === column.fx.replace(/[\[\]]/gi, '').split(/[*/+-]/)[0])) {
                            const fxArray = column.fx.replace(/[\[\]]/gi, '').split(/[*/+-]/);
                            const umn = column.fx.indexOf('*') != -1 ? '*' : false;
                            const raz = column.fx.indexOf('/') != -1 ? '/' : false;
                            const minus = column.fx.indexOf('-') != -1 ? '-' : false;
                            const plus = column.fx.indexOf('+') != -1 ? '+' : false;
                            let action = '==';
                            
                            if (umn) action = '*';
                            if (raz) action = '/';
                            if (minus) action = '-';
                            if (plus) action = '+';
    
                            records[iCol] = eval(records[iRec] + action + fxArray[1]);
    
                            // console.log({
                            //     fx: column.fx,
                            //     fxArray,
                            //     result: eval(records[iRec] + action + fxArray[1]),
                            //     iRec,
                            //     iCol,
                            //     umn,
                            //     raz,
                            //     minus,
                            //     plus,
                            // });
                        };
                    });
                });
            }

            try {
                if (!Array.isArray(column.where)) {
                    arrayData.map((records) => {
                        records.map((record, iRec) => {
                            if (iRec === iCol) {
                                console.log({
                                    record: records[iRec],
                                    operator: column.where.operator || dataWhereColumns[0],
                                    value: column.where.value,
                                    fx: `${records[iRec]}${column.where.operator}${column.where.value}`
                                });
                                
                                if (eval(`${typeof records[iRec] === 'string' ? "'" + records[iRec] + "'" : records[iRec]}${column.where.operator || dataWhereColumns[0]}${typeof column.where.value === 'string' ? "'" + column.where.value + "'" : column.where.value}`)) newArrayWhereData.push(records);
                            };
                            
                        });
                            
                        // if (iRec === iCol) eval(record[iCol] + column.where.operator + column.where.value);
                    });
                }
            } catch {
                alert('Ошибка расчета условий для колонки: ' + column.title);
            }
        });

        console.log({arrayData, newArrayWhereData});

        const allReportData = newArrayWhereData.length > 0 ? [...newArrayWhereData] : [...arrayData];

        setNewDataReport(allReportData);
        return allReportData;
    }

    const handlePreview = () => {
        const bearerToken = localStorage.getItem('api_token');
        const newDataReport = filterDataReport();

        const dataForm = {
            format: selectedExtension,
            name,
            headers: customWhereColumns,
            data: newDataReport.length > 0 ? newDataReport : dataReport
        };

        // alert(JSON.stringify(dataForm))

        fetch(`${REACT_APP_API_URL}/api/report/export/${idReport}/preview`, {
            method: 'POST',
            headers: {
              'Authorization': 'Bearer ' + bearerToken,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(dataForm),
          })
            .then( res => res.blob() )
            .then( blob => {
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = name + '.' + selectedExtension;
                document.body.appendChild(a); 
                a.click();    
                a.remove();
            });
    };

    const handleChangeToReport = () => {
        const bearerToken = localStorage.getItem('api_token');

        filterDataReport();

         // fixme продумать логику изменения значений в столбцах по формулам fx
        // customColumns.map((column, iCol) => {
        //     if (column.fx) {
        //         let iZarplata = null;
        //         let iStavka = null;
        //         customColumns.find((column, index) => {
        //             if (column.name === 'zarplata') iZarplata = index;
        //         });
        //         customColumns.find((column, index) => {
        //             if (column.name === 'stavka') iStavka = index;
        //         });
        //         console.log({iZarplata, iStavka});
                
        //         console.log('Считаем fx колонки ' + column.title);
        //         const fxParse = column.fx.replace(/[\[\]]/gi, '');
        //         console.log(column);

        //         dataReport.map((record, iRec) => {
        //             record[iCol] = eval(fxParse.replace('zarplata', record[iZarplata]).replace('stavka', String(record[iStavka])));
        //         });
        //     }
            
        // });


        console.log('Строки в отчете');
        console.log(dataReport);

        const dataForm = {
            id: idReport,
            category_id: selectedCategory,
            name,
            extension: selectedExtension,
            headers: customWhereColumns,
            whereData: newDataReport
        };

        console.log('Данные с формы');
        console.log(dataForm);

        fetch(`${REACT_APP_API_URL}/api/report`, {
            method: 'PATCH',
            headers: {
              'Authorization': 'Bearer ' + bearerToken,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(dataForm),
          })
            .then((response) => response.json())
            .then((data) => {
                if (data.success) {
                    alert('Отчет изменен');
                } else alert(JSON.stringify(data));
            });
    };
    
    return (
        <div className={styles.container}>
            <div className={styles.box}>
                <input
                    type="text"
                    placeholder="Введите название отчета"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                />
                <select className={styles.slctPart} value={selectedCategory} onChange={(e) => setSelectedCategory(e.target.value)}>
                    {dataCategories.map(category => (
                        <option hidden={!category.id ? true : false} key={category.id} value={category.id}>{category.name}</option>
                    ))}
                </select>
                <select className={styles.slctPart} value={selectedExtension} onChange={(e) => setSelectedExtension(e.target.value)}>
                    {dataExtensions.map((extension) => (
                        <option value={extension}>{extension}</option>
                    ))}
                </select>
                <button className={styles.btn_preview} onClick={handlePreview}>Предпросмотр</button>
            </div>


            <div className={styles.box3}>
                <div className={styles.box__title}>
                    <img src={screp} alt="screp"/>
                    <label>Добавить условие для столбца:</label>
                    <span className={styles.addColumnBtn} onClick={handleAddWhereColumn}>+</span>
                </div>
            </div>
                {customWhereColumns.map((column) => !Array.isArray(column.where) && (
                    <div key={column.name} className={styles.column}>
                        <select 
                            className={styles.slct_column}
                            onChange={(e) => handleColumnWhereChange(e.target.value, 'name')}
                        >
                            {dataHeaders.map(header => (
                                <option selected={header.name === column.name ? true : false} key={header.name} value={header.name}>{header.title}</option>
                            ))}
                        </select>
                        <select 
                            className={styles.slct_column} 
                            onChange={(e) => handleColumnWhereChange(column.name, "operator", e.target.value, true)}
                        >
                            {dataWhereColumns.map(where => (
                                <option selected={column.where.operator === where ? true : false} key={where} value={where}>{where}</option>
                            ))}
                        </select>
                        <input
                            type="text"
                            className={styles.inpt_js}
                            value={column.where.value}
                            onChange={(e) => handleColumnWhereChange(column.name, "value", e.target.value, true)}
                            placeholder="Значение"
                        />
                        <button onClick={() => handleDeleteWhereColumn(column.name)}>Удалить</button>
                    </div>
                ))}

            <div>
                <div className={styles.box__title}>
                    <img src={screp} alt="screp"/>
                    <label>Настройка столбцов:</label>
                    <span className={styles.addColumnBtn} onClick={handleAddColumn}>+</span>
                </div>
            </div>
                {customWhereColumns.map((column, index) => (
                    <div key={index} className={styles.column}>
                        <span>{index + 1}.</span>
                        <div className={styles.radioGroup}>
                            <label>
                                <input
                                    type="radio"
                                    value="a"
                                    checked={column.type === "a"}
                                    onChange={() => handleColumnChange(index, "type", "a")}
                                /> a
                            </label>
                            <label>
                                <input
                                    type="radio"
                                    value="fx"
                                    checked={column.type === "fx"}
                                    onChange={() => handleColumnChange(index, "type", "fx")}
                                /> f(x)
                            </label>
                        </div>
                        {column.type === "a" && column.name.indexOf('new_column_') === -1 && (
                            <select className={styles.slct_column} onChange={(e) => handleColumnChange(index, "title", e.target.value)}>
                                {dataHeaders.map(header => (
                                    <option selected={header.name === column.name ? true : false} key={header.name} value={header.title}>{header.title}</option>
                                ))}
                            </select>
                        )}
                        {column.name.indexOf('new_column_') === 0 && (
                            <input
                                type="text"
                                className={styles.inpt_js}
                                value={column.title}
                                onChange={(e) => handleColumnChange(index, "title", e.target.value)}
                                placeholder="Введите заголовок"
                            />
                        )}
                        {column.type === "fx" && (
                            <input
                                type="text"
                                className={styles.inpt_js}
                                value={column.where.fx}
                                onChange={(e) => handleColumnChange(index, "fx", e.target.value)}
                                placeholder={column.fx || `[${column.name}]`}
                                onDoubleClick={(e) => navigator.clipboard.writeText(`[${column.name}]`)}
                            />
                        )}
                        <button onClick={() => handleDeleteColumn(index)}>Удалить</button>
                    </div>
                ))}

            <button onClick={handleChangeToReport} className={styles.addToReportBtn}>Изменить отчет</button>
        </div>
    );
};

export default ReportCreation;
