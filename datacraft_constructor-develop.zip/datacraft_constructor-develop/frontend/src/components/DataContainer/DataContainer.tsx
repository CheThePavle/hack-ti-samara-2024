import styles from "../Home/Home.module.sass";
import {FC, ReactNode} from "react";

interface DataContainerProps {
    title: string;
    children?: ReactNode; // Добавляем возможность передавать children
}

const DataContainer: FC<DataContainerProps> = ({ title , children}) => {
    return(
        <div className={styles.content}>
            <div className={styles.content__nameDoc}>
                <h3>{title}</h3>
            </div>
            {children && <div className={styles.content__children}>{children}</div>}
        </div>
    )
}

export default DataContainer;