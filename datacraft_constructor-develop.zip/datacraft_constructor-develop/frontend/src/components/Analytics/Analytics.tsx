import { useState, useEffect } from "react";
import styles from "./Analytics.module.sass";
import { Bar, Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement } from 'chart.js';
import { ChartData } from 'chart.js';
import REACT_APP_API_URL from "../../../env.ts";
import jsPDF from "jspdf";
import PptxGenJS from "pptxgenjs";
import { Document, Packer, Paragraph, TextRun, ImageRun } from "docx";
import html2canvas from "html2canvas";

ChartJS.register(
    CategoryScale,
    LinearScale,
    BarElement,
    ArcElement,
    Title,
    Tooltip,
    Legend
);

interface ReportHeader {
    name: string;
    title: string;
}

interface Report {
    id: number;
    name: string;
    headers: ReportHeader[];
    data: (string | number)[][];
}

const Analytics = () => {
    const [reports, setReports] = useState<Report[]>([]);
    const [selectedReports, setSelectedReports] = useState<Report[]>([]);
    const [localColumns, setLocalColumns] = useState<string[]>([]);
    const [textColumns, setTextColumns] = useState<string[]>([]);
    const [displayedColumns, setDisplayedColumns] = useState<string[]>([]);
    const [displayedTextColumns, setDisplayedTextColumns] = useState<string[]>([]);
    const [chartDatasets, setChartDatasets] = useState<ChartData<any>[]>([]);
    const [textChartDatasets, setTextChartDatasets] = useState<ChartData<'doughnut'>[]>([]);
    const [loading, setLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchReports = async () => {
            setLoading(true);
            setError(null);
            try {
                const response = await fetch(`${REACT_APP_API_URL}/api/report/list`, {
                    method: 'GET',
                    headers: {
                        'Authorization': 'Bearer ' + localStorage.getItem('api_token'),
                    },
                });
                const data = await response.json();
                if (response.ok && data.success) {
                    const formattedReports = data.data.map((report: any) => ({
                        id: report.id,
                        name: report.name,
                        headers: report.headers || [],
                        data: report.data || [],
                    }));
                    setReports(formattedReports);
                } else {
                    setError(data.message || "Не удалось загрузить отчёты.");
                }
            } catch (error) {
                setError("Ошибка при получении отчётов: " + error);
            } finally {
                setLoading(false);
            }
        };
        fetchReports();
    }, []);

    useEffect(() => {
        if (selectedReports.length > 0) {
            const report = selectedReports[0];

            // Reset columns when selecting a new report
            setLocalColumns([]);
            setTextColumns([]);
            setDisplayedColumns([]);
            setDisplayedTextColumns([]);

            const numericColumns: string[] = [];
            const textColumns: string[] = [];

            report.headers.forEach((header, index) => {
                const isNumeric = report.data.every(item => typeof item[index] === 'number');
                if (isNumeric) {
                    numericColumns.push(header.name);
                } else {
                    textColumns.push(header.name);
                }
            });

            setLocalColumns(numericColumns);
            setTextColumns(textColumns);
        }
    }, [selectedReports]);

    useEffect(() => {
        if (selectedReports.length > 0 && displayedColumns.length > 0) {
            const newChartDatasets = selectedReports.map((report) => {
                const labels = report.data.map(item => item[0]);
                const datasets = displayedColumns.map((column, index) => {
                    const columnIndex = report.headers.findIndex(header => header.name === column);
                    const data = report.data.map(item => item[columnIndex]);

                    return {
                        label: column,
                        data,
                        backgroundColor: `rgba(${(index * 70) % 255}, ${(index * 100) % 255}, ${(index * 150) % 255}, 0.8)`,
                        borderColor: `rgba(${(index * 70) % 255}, ${(index * 100) % 255}, ${(index * 150) % 255}, 1)`,
                        borderWidth: 1,
                    };
                });

                return { labels, datasets };
            });
            setChartDatasets(newChartDatasets);
        }

        if (textColumns.length > 0 && displayedTextColumns.length > 0) {
            const newTextChartDatasets = selectedReports.flatMap(report => {
                return displayedTextColumns.map(column => {
                    const textCount: { [key: string]: number } = {};
                    const columnIndex = report.headers.findIndex(header => header.name === column);

                    report.data.forEach(item => {
                        const textValue = item[columnIndex];
                        if (typeof textValue === 'string') {
                            textCount[textValue] = (textCount[textValue] || 0) + 1;
                        }
                    });

                    const textLabels = Object.keys(textCount);
                    const textValues = Object.values(textCount);

                    return {
                        labels: textLabels,
                        datasets: [{
                            label: `Текстовые данные из ${column}`,
                            data: textValues,
                            backgroundColor: textLabels.map((_, index) => `rgba(${(index * 70) % 255}, ${(index * 100) % 255}, ${(index * 150) % 255}, 0.8)`),
                            borderColor: textLabels.map((_, index) => `rgba(${(index * 70) % 255}, ${(index * 100) % 255}, ${(index * 150) % 255}, 1)`),
                            borderWidth: 1,
                        }]
                    };
                });
            });

            setTextChartDatasets(newTextChartDatasets);
        }
    }, [selectedReports, displayedColumns, displayedTextColumns]);

    const handleSelectReport = async (reportId: number) => {
        setLoading(true);
        setError(null);
        try {
            const response = await fetch(`${REACT_APP_API_URL}/api/report/${reportId}`, {
                method: 'GET',
                headers: {
                    'Authorization': 'Bearer ' + localStorage.getItem('api_token'),
                },
            });
            const data = await response.json();
            if (response.ok && data.success) {
                const report: Report = {
                    id: data.data.id,
                    name: data.data.name,
                    headers: data.data.headers || [],
                    data: data.data.data || [],
                };
                setSelectedReports([report]);
            } else {
                setError(data.message || "Не удалось загрузить отчёт.");
            }
        } catch (error) {
            setError("Ошибка при получении отчёта: " + error);
        } finally {
            setLoading(false);
        }
    };

    const handleToggleColumn = (columnName: string) => {
        setDisplayedColumns(prevColumns =>
            prevColumns.includes(columnName)
                ? prevColumns.filter(col => col !== columnName)
                : [...prevColumns, columnName]
        );
    };

    const handleToggleTextColumn = (columnName: string) => {
        setDisplayedTextColumns(prevColumns =>
            prevColumns.includes(columnName)
                ? prevColumns.filter(col => col !== columnName)
                : [...prevColumns, columnName]
        );
    };

    const base64ToArrayBuffer = (base64: string) => {
        const binaryString = window.atob(base64);
        const len = binaryString.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
            bytes[i] = binaryString.charCodeAt(i);
        }
        return bytes.buffer;
    };

    const handleDownloadChart = async (format: 'png' | 'pdf' | 'pptx' | 'docx') => {
        const chartContainer = document.getElementById('chartContainer');
        if (!chartContainer) return;

        if (format === 'png') {
            const canvas = await html2canvas(chartContainer);
            const link = document.createElement('a');
            link.href = canvas.toDataURL('image/png');
            link.download = 'chart.png';
            link.click();
        } else if (format === 'pdf') {
            const canvas = await html2canvas(chartContainer);
            const pdf = new jsPDF();
            pdf.addImage(canvas.toDataURL('image/png'), 'PNG', 10, 10, 180, 160);
            pdf.save('chart.pdf');
        } else if (format === 'pptx') {
            const pptx = new PptxGenJS();
            const slide = pptx.addSlide();
            const canvas = await html2canvas(chartContainer);
            slide.addImage({ data: canvas.toDataURL('image/png'), x: 0.5, y: 0.5, w: 8, h: 5 });
            pptx.writeFile({ fileName: 'chart.pptx' });
        } else if (format === 'docx') {
            const canvas = await html2canvas(chartContainer);
            const imageData = canvas.toDataURL('image/png').replace(/^data:image\/png;base64,/, "");
            const arrayBuffer = base64ToArrayBuffer(imageData);

            const doc = new Document({
                sections: [
                    {
                        children: [
                            new Paragraph({
                                text: "Chart Report",
                                heading: "Heading1",
                            }),
                            new Paragraph("The following chart(s) are included in this report:"),
                            new Paragraph({
                                children: [
                                    new ImageRun({
                                        data: arrayBuffer,
                                        transformation: {
                                            width: 500,
                                            height: 300,
                                        },
                                    }),
                                ],
                            }),
                        ],
                    },
                ],
            });

            const blob = await Packer.toBlob(doc);
            const link = document.createElement("a");
            link.href = URL.createObjectURL(blob);
            link.download = "chart.docx";
            link.click();
        }
    };



    return (
        <div>
            <div className={styles.reportSelection}>
                <label>Выберите отчет:</label>
                <select onChange={(e) => handleSelectReport(Number(e.target.value))} defaultValue="">
                    <option value="" disabled>Выберите отчет</option>
                    {reports.map((report) => (
                        <option key={report.id} value={report.id}>{report.name}</option>
                    ))}
                </select>
            </div>

            {loading && <p>Загрузка...</p>}
            {error && <p className={styles.error}>{error}</p>}

            {selectedReports.length > 0 && (
                <div>
                    <h3>Выберите числовые столбцы:</h3>
                    {localColumns.map((column) => (
                        <button
                            key={column}
                            className={`${styles.columnButton} ${displayedColumns.includes(column) ? styles.selected : ''}`}
                            onClick={() => handleToggleColumn(column)}
                        >
                            {column} {displayedColumns.includes(column) ? '✓' : ''}
                        </button>
                    ))}
                    <h3>Выберите текстовые столбцы:</h3>
                    {textColumns.map((column) => (
                        <button
                            key={column}
                            className={`${styles.columnButton} ${displayedTextColumns.includes(column) ? styles.selected : ''}`}
                            onClick={() => handleToggleTextColumn(column)}
                        >
                            {column} {displayedTextColumns.includes(column) ? '✓' : ''}
                        </button>
                    ))}
                </div>
            )}

            <div id="chartContainer">
                {chartDatasets.map((chartData, index) => (
                    <Bar key={index} data={chartData} options={{ responsive: true }} />
                ))}
                {textChartDatasets.map((chartData, index) => (
                    <Doughnut key={index} data={chartData} options={{ responsive: true }} />
                ))}
            </div>

            <div className={styles.downloadButtons}>
                <button onClick={() => handleDownloadChart('png')}>Скачать PNG</button>
                <button onClick={() => handleDownloadChart('pdf')}>Скачать PDF</button>
                <button onClick={() => handleDownloadChart('pptx')}>Скачать PPTX</button>
                <button onClick={() => handleDownloadChart('docx')}>Скачать DOCX</button>
            </div>
        </div>
    );
};

export default Analytics;
