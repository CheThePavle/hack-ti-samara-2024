import { ChangeEvent, FC, useEffect, useState } from "react";
import styles from "./Reports.module.sass";
import REACT_APP_API_URL from "../../../env.ts";
import { User } from "../AccessControl/AccessControl.interface.ts";

import edit from '../../assets/edit2.svg';
import del from '../../assets/del.svg';
import download from '../../assets/download2.svg';
import ref50 from '../../assets/ref50.svg';

interface Report {
    id: number;
    name: string;
    created_at: string;
    updated_at: string;
    creator: string;
    category: string | null;
    extension?: string; // Добавляем extension как необязательное поле
    basket?: string;
}

interface Category {
    id: number | null;
    name: string;
}

interface ReportsProps {
    onReportSelect: (report: number) => void;
}

const Reports: FC<ReportsProps> = ({ onReportSelect }) => {
    const [reports, setReports] = useState<Report[]>([]);
    const [selectedReport, setSelectedReport] = useState<Report | null>(null);
    const [categories, setCategories] = useState<Category[]>([]);
    const [users, setUsers] = useState<User[]>([]);
    const [selectedUser, setSelectedUser] = useState<number | null>(null);
    const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
    const [selectedBasket, setSelectedBasket] = useState<boolean>(false);
    const [searchQuery, setSearchQuery] = useState<string>("");

    useEffect(() => {
        const fetchReports = async () => {
            try {
                const response = await fetch(`${REACT_APP_API_URL}/api/report/list`, {
                    method: 'GET',
                    headers: {
                        'Authorization': 'Bearer ' + localStorage.getItem('api_token'),
                    },
                });

                const data = await response.json();

                if (response.ok && data.success) {
                    const formattedReports = data.data.map((report: any) => ({
                        id: report.id,
                        name: report.name,
                        extension: report.extension,
                        basket: report.basket,
                        created_at: report.created_at,
                        updated_at: report.updated_at,
                        creator: report.user?.name || 'Неизвестно',
                        category: report.category?.name || 'Без категории',
                    }));
                    setReports(formattedReports);
                } else {
                    console.error("Ошибка при получении отчётов:", data);
                }
            } catch (error) {
                console.error("Ошибка при получении отчётов:", error);
            }
        };

        const fetchCategories = async () => {
            try {
                const response = await fetch(`${REACT_APP_API_URL}/api/categories`, {
                    method: 'GET',
                    headers: {
                        'Authorization': 'Bearer ' + localStorage.getItem('api_token'),
                    },
                });

                const data = await response.json();

                if (response.ok && data.success) {
                    setCategories(data.data);
                } else {
                    console.error("Ошибка при получении категорий:", data);
                }
            } catch (error) {
                console.error("Ошибка при получении категорий:", error);
            }
        };

        fetchReports();
        fetchCategories();
        const intervalId = setInterval(fetchReports, 5000);
        return () => clearInterval(intervalId);
    }, []);

    useEffect(() => {
        const fetchUsers = async () => {
            try {
                const response = await fetch(`${REACT_APP_API_URL}/api/users?confirmed=true`, {
                    method: 'GET',
                    headers: {
                        'Authorization': 'Bearer ' + localStorage.getItem('api_token'),
                    },
                });

                const data = await response.json();

                if (response.ok && data.success) {
                    setUsers(data.data);
                } else {
                    console.error("Ошибка при получении пользователей:", data);
                }
            } catch (error) {
                console.error("Ошибка при получении пользователей:", error);
            }
        };

        fetchUsers();
    }, []);

    // Удаление отчёта
    const handleDeleteReport = async (id: number, basket = !selectedBasket) => {
        try {
            const dataForm = { report_id: id };
            if (basket) dataForm.basket = 1;    
            
            const response = await fetch(`${REACT_APP_API_URL}/api/report`, {
                method: 'DELETE',
                headers: {
                    'Authorization': 'Bearer ' + localStorage.getItem('api_token'),
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(dataForm)
            });

            const data = await response.json();

            if (response.ok && data.success) {
                setReports((prevReports) => prevReports.filter((report) => report.id !== id));
                console.log(data.message);
            } else {
                console.error(data.message || 'Не удалось удалить отчет');
            }
        } catch (error) {
            console.error('Ошибка при удалении отчета:', error);
        }
    };

    // Редактирование отчёта
    const handleEditReport = (id: number) => {
        onReportSelect(id);
        console.log(id)
    };

    const handleRevertBasket = (id: number) => {
        fetch(`${REACT_APP_API_URL}/api/report`, {
            method: 'PATCH',
            headers: {
              'Authorization': 'Bearer ' + localStorage.getItem('api_token'),
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                "id": id,
                "basket": null
            }),
          })
            .then((response) => response.json())
            .then((data) => {
                if (data.success) {
                    alert('Отчет восстановлен');
                } else alert(JSON.stringify(data));
            });
        console.log(id);
    };

    // Экспорт отчёта
    const handleExportReport = async (id: number, format: string | undefined) => {
        if (!format) {
            console.error("Формат экспорта не задан");
            return;
        }

        try {
            const url = `${REACT_APP_API_URL}/api/report/export/${id}?format=${format}`;

            const response = await fetch(url, {
                method: 'GET',
                headers: {
                    'Authorization': 'Bearer ' + localStorage.getItem('api_token'),
                },
            });

            if (response.ok) {
                const blob = await response.blob();
                const downloadUrl = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = downloadUrl;
                a.download = `report-${id}.${format}`;
                document.body.appendChild(a);
                a.click();
                a.remove();
                window.URL.revokeObjectURL(downloadUrl);
                console.log('Отчет успешно экспортирован');
            } else {
                console.error('Не удалось экспортировать отчет');
            }
        } catch (error) {
            console.error('Ошибка при экспорте отчета:', error);
        }
    };

    const handleUserChange = (event: ChangeEvent<HTMLSelectElement>) => {
        const userId = Number(event.target.value);
        setSelectedUser(userId);
    };

    const handleCategoryChange = (event: ChangeEvent<HTMLSelectElement>) => {
        const categoryId = Number(event.target.value);
        setSelectedCategory(categoryId !== 0 ? categoryId : null);
    };

    const handleSearchChange = (event: ChangeEvent<HTMLInputElement>) => {
        setSearchQuery(event.target.value);
    };

    const handleBasket = () => {
        setSelectedBasket(!selectedBasket);
    };

    const filteredReports = reports.filter((report) => {
        const matchesCategory = selectedCategory === null || report.category === categories.find(category => category.id === selectedCategory)?.name;
        const matchesUser = selectedUser === null || report.creator === users.find(user => user.id === selectedUser)?.name;
        const matchesSearch = [
            report.name,
            report.creator,
            report.category || '',
        ].some((field) =>
            field.toLowerCase().includes(searchQuery.toLowerCase())
        );

        if (selectedBasket) {
            return report.basket && matchesCategory && matchesUser && matchesSearch;
        } else return matchesCategory && matchesUser && matchesSearch;
    });

    return (
        <div className={styles.container}>
            <div className={styles.container__btn}>
                <select className={styles.container__btn_item} onChange={handleUserChange}>
                    <option value="0">Выбор сотрудника</option>
                    {users.map((user) => (
                        <option key={user.id} value={user.id}>
                            {user.name}
                        </option>
                    ))}
                </select>
                <select className={styles.container__btn_item} onChange={handleCategoryChange}>
                    <option>Выбор категории</option>
                    {categories.map((category) => (
                        <option key={category.id || 0} value={category.id || 0}>
                            {category.name}
                        </option>
                    ))}
                </select>
                <label>В корзине
                    <input
                        type="checkbox"
                        placeholder="В корзине"
                        onChange={handleBasket}
                    />
                </label>
                <input
                    type="text"
                    className={styles.search}
                    placeholder="Поиск"
                    value={searchQuery}
                    onChange={handleSearchChange}
                />
            </div>
            <div className={styles.table__wrapper}>
                <table className={styles.table}>
                    <thead>
                    <tr>
                        <th>Наименование</th>
                        <th>Дата создания</th>
                        <th>Дата изменения</th>
                        <th>Кто создал</th>
                        <th>Категория</th>
                    </tr>
                    </thead>
                    <tbody>
                    {filteredReports.map((report) => (
                        <tr
                            key={report.id}
                            className={selectedReport?.id === report.id ? styles.selected : ''}
                            onClick={() => setSelectedReport(report)}
                        >
                            <td>{report.name}</td>
                            <td>{report.created_at}</td>
                            <td>{report.updated_at}</td>
                            <td>{report.creator}</td>
                            <td>{report.category}</td>
                            <td className={styles.btn_icon}>
                                {selectedBasket && <img src={ref50} width="24" alt="Восстановить" onClick={(e) => { e.stopPropagation(); handleRevertBasket(report.id); }} />}
                                <img src={edit} alt="Редактировать" onClick={(e) => { e.stopPropagation(); handleEditReport(report.id); }} />
                                <img src={del} alt="Удалить" onClick={(e) => { e.stopPropagation(); handleDeleteReport(report.id); }} />
                                <img src={download} alt="Экспорт" onClick={(e) => { e.stopPropagation(); handleExportReport(report.id, report.extension); }} />
                            </td>
                        </tr>
                    ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default Reports;
