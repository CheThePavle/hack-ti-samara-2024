import React, { useState } from 'react';
import styles from './Home.module.sass';
import { useAuth } from "../../context/AuthContext.tsx";
import DataContainer from "../DataContainer/DataContainer.tsx";
import Reports from "../Reports/Reports.tsx";
import ReportCreation from "../ReportCreation/ReportCreation.tsx";
import Analytics from "../Analytics/Analytics.tsx";
import AccessControl from "../AccessControl/AccessControl.tsx";
import REACT_APP_API_URL from '../../../env.ts';

interface TabItem {
    title: string;
    content: JSX.Element;
}

interface TabContentProps {
    content: JSX.Element;
}

const Home: React.FC = () => {
    const { logout } = useAuth();
    const [active, setActive] = useState<number>(0);
    const [selectedReportId, setSelectedReportId] = useState<number | null>(null);
    const userRole = localStorage.getItem('role');
    const isConfirmed = userRole === '2' || (userRole === '1' && localStorage.getItem('confirmed') !== 'null');


    const onReportSelect = (id: number) => {
        setSelectedReportId(id);
        setActive(1);
    };

    const items: TabItem[] = isConfirmed ? [
        {
            title: 'Отчеты',
            content: (
                <DataContainer title="Отчеты">
                    <Reports onReportSelect={onReportSelect} />
                </DataContainer>
            ),
        },
        {
            title: 'Настройка отчетов',
            content: (
                <DataContainer title="Настройка отчетов">
                    {selectedReportId !== null ? (
                        <ReportCreation idReport={selectedReportId} />
                    ) : (
                        <p>Выберите отчет из системы</p>
                    )}
                </DataContainer>
            ),
        },
        {
            title: 'Аналитика',
            content: (
                <DataContainer title="Аналитика">
                    <Analytics/>
                </DataContainer>
            ),
        },
        ...(userRole === '2' ? [{
            title: 'Доступ',
            content: (
                <DataContainer title="Доступ">
                    <AccessControl/>
                </DataContainer>
            ),
        }] : []),
    ] : [];

    const openTab = (e: React.MouseEvent<HTMLButtonElement>) => setActive(+e.currentTarget.dataset.index!);

    const TabContent: React.FC<TabContentProps> = ({ content }) => (
        <div className={styles.tabContent}>
            <div>{content}</div>
        </div>
    );

    const handleUploadfile = (e: React.ChangeEvent<HTMLInputElement>) => {
        const bearerToken = localStorage.getItem('api_token');
        e.preventDefault();
        const data = new FormData();
        if (e.target.files) {
            data.append('file', e.target.files[0]);
            console.log('Выбранный файл');
            console.log(e.target.files[0]);

            fetch(`${REACT_APP_API_URL}/api/report/import`, {
                method: 'POST',
                headers: {
                    'Authorization': 'Bearer ' + bearerToken
                },
                body: data
            })
                .then((response) => response.json())
                .then((data) => {
                    if (data.success) {
                        alert('Отчет импортирован');
                        console.log('Отчет импортирован');
                        console.log(data);
                    } else alert(JSON.stringify(data));
                });
        }
    }

    return (
        <div className={styles.container}>
            <div className={styles.container__wrap}>
                <div className={styles.header}>
                    <div className={styles.header__btn}>
                        <h1>Конструктор отчетов</h1>
                        {isConfirmed && (
                        <div className={styles.header__itemBtn} style={{ position: 'relative' }}>

                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M12 17.72V0.5" stroke="white" strokeWidth="2" strokeMiterlimit="10" />
                                <path d="M4.34998 10.06L12 17.72L19.65 10.06" stroke="white" strokeWidth="2" strokeMiterlimit="10" />
                                <path d="M19.65 18.67V22.5H4.34998V18.67" stroke="white" strokeWidth="2" strokeMiterlimit="10" />
                            </svg>

                                <p>Выбрать отчет из системы</p>

                            <input
                                type="file"
                                style={{ position: 'absolute', width: '100%', height: '100%', opacity: 0, cursor: 'pointer' }}
                                accept=".xlsx,.xls,.ods,.csv,.json"
                                onChange={(e) => handleUploadfile(e)}
                            />
                        </div>
                        )}
                    </div>
                    <p>Добро пожаловать, {localStorage.getItem('name') || 'гость'}!</p>

                    <p className={styles.exit} onClick={logout}>Выйти</p>
                </div>

                <div className={styles.tabs}>
                    {isConfirmed ? (
                        items.map((n, i) => (
                            <button
                                key={i}
                                className={`${styles.tablinks} ${i === active ? styles.active : ''}`}
                                onClick={openTab}
                                data-index={i}
                            >
                                {n.title}
                            </button>
                        ))
                    ) : (
                        <p className={styles.error_user}>Ваш профиль еще не подтвержден, <br/> зайдите позже!</p>
                    )}
                </div>
                {isConfirmed && items[active] && <TabContent {...items[active]} />}
            </div>
        </div>
    );
};

export default Home;
