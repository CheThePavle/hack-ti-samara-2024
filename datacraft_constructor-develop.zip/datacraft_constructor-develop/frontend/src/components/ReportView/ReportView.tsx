

const ReportView = () => {
    return (
        <div>
            <h2>Просмотр вновь созданного отчета</h2>
        </div>
    );
};

export default ReportView;
