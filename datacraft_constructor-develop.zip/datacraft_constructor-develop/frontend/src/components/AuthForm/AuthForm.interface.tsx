export interface AuthFormProps {
    isRegister: boolean;
}