// import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import AuthForm from './components/AuthForm/AuthForm.tsx';
import Home from './components/Home/Home.tsx';
// import ReportCreation from './components/ReportCreation/ReportCreation';
// import ReportView from './components/ReportView/ReportView';
// import Analytics from './components/Analytics/Analytics';
// import Reports from "./components/Reports/Reports.tsx";

const ProtectedRoute = ({ children }: { children: JSX.Element }) => {
    const { isAuthenticated } = useAuth();
    return isAuthenticated ? children : <Navigate to="/login" />;
};

const App = () => {
    return (
        <Router>
            <AuthProvider>
                <Routes>
                    <Route path="/login" element={<AuthForm isRegister={false} />} />
                    <Route path="/register" element={<AuthForm isRegister={true} />} />

                    <Route path="/home" element={<ProtectedRoute><Home /></ProtectedRoute>} />
                    {/*<Route path="/create-report" element={<ProtectedRoute><ReportCreation/></ProtectedRoute>} />*/}
                    {/*<Route path="/view-reports" element={<ProtectedRoute><ReportView/></ProtectedRoute>} />*/}
                    {/*<Route path="/analytics" element={<ProtectedRoute><Analytics /></ProtectedRoute>} />*/}
                    {/*<Route path="/reports" element={<ProtectedRoute><Reports /></ProtectedRoute>} />*/}

                    <Route path="*" element={<Navigate to="/login" />} />
                </Routes>
            </AuthProvider>
        </Router>
    );
};

export default App;
